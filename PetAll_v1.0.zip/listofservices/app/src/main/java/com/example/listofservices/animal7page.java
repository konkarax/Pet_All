package com.example.listofservices;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class animal7page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal7page);
    }
}