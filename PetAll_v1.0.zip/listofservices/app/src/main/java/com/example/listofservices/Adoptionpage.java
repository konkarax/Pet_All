package com.example.listofservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Adoptionpage extends AppCompatActivity {

    private Button buttonanimal1;
    private Button buttonanimal2;
    private Button buttonanimal3;
    private Button buttonanimal4;
    private Button buttonanimal5;
    private Button buttonanimal6;
    private Button buttonanimal7;
    private Button buttonanimal8;
    private Button buttonanimal9;
    private Button buttonanimal10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adoptionpage);

        buttonanimal1 = (Button) findViewById(R.id.animal1);
        buttonanimal2 = (Button) findViewById(R.id.animal2);
        buttonanimal3 = (Button) findViewById(R.id.animal3);
        buttonanimal4 = (Button) findViewById(R.id.animal4);
        buttonanimal5 = (Button) findViewById(R.id.animal5);
        buttonanimal6 = (Button) findViewById(R.id.animal6);
        buttonanimal7 = (Button) findViewById(R.id.animal7);
        buttonanimal8 = (Button) findViewById(R.id.animal8);
        buttonanimal9 = (Button) findViewById(R.id.animal9);
        buttonanimal10 = (Button) findViewById(R.id.animal10);


        buttonanimal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Adoptionpage.this, animal1page.class);
                startActivity(intent);
            }
        });

        buttonanimal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Adoptionpage.this, animal2page.class);
                startActivity(intent);
            }
        });

        buttonanimal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Adoptionpage.this, animal3page.class);
                startActivity(intent);
            }
        });

        buttonanimal4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Adoptionpage.this, animal4page.class);
                startActivity(intent);
            }
        });

        buttonanimal5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Adoptionpage.this, animal5page.class);
                startActivity(intent);
            }
        });

        buttonanimal6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Adoptionpage.this, animal6page.class);
                startActivity(intent);
            }
        });

        buttonanimal7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Adoptionpage.this, animal7page.class);
                startActivity(intent);
            }
        });

        buttonanimal8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Adoptionpage.this, animal8page.class);
                startActivity(intent);
            }
        });

        buttonanimal9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Adoptionpage.this, animal9page.class);
                startActivity(intent);
            }
        });

        buttonanimal10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Adoptionpage.this, animal10page.class);
                startActivity(intent);
            }
        });

    }


}