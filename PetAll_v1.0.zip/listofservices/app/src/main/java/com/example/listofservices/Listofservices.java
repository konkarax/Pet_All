package com.example.listofservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Listofservices extends AppCompatActivity {

    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
    private Button button8;
    private Button button9;
    private Button button10;
    private Button button11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listofservices);

        button1 = (Button) findViewById(R.id.chatroom);
        button2 = (Button) findViewById(R.id.forum);
        button3 = (Button) findViewById(R.id.petexperts);
        button4 = (Button) findViewById(R.id.petfriendlyspaces);
        button5 = (Button) findViewById(R.id.petshops);
        button6= (Button) findViewById(R.id.vets);
        button7 = (Button) findViewById(R.id.shelters);
        button8 = (Button) findViewById(R.id.pethosting);
        button9 = (Button) findViewById(R.id.petgroomers);
        button10 = (Button) findViewById(R.id.adoption);
        button11 = (Button) findViewById(R.id.pethelpers);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Chatroompage.class);
                startActivity(intent);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Forumpage.class);
                startActivity(intent);
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Petexpertscatalog.class);
                startActivity(intent);
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Petfriendlyspacescatalog.class);
                startActivity(intent);
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Petshopscatalog.class);
                startActivity(intent);
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Vetscatalog.class);
                startActivity(intent);
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Shelterscatalog.class);
                startActivity(intent);
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Pethostingcatalog.class);
                startActivity(intent);
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Petgroomerscatalog.class);
                startActivity(intent);
            }
        });

        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Adoptionpage.class);
                startActivity(intent);
            }
        });

        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Listofservices.this, Pethelperscatalog.class);
                startActivity(intent);
            }
        });

    }


}